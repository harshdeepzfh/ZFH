import { useEffect, useState, useRef } from 'react';
import { 
  Menu, X, Check, Star, ArrowRight, Shield, Lock, RotateCcw, Download,
  Calendar, Lightbulb, Target, TrendingUp, BookOpen, Zap, Eye, Cog,
  ChartLine, CreditCard, Wallet, MapPin, RefreshCw, Mail, ListChecks,
  GraduationCap, Sun, Minus, TriangleAlert, Briefcase, TrendingDown,
  Gift, Clock, ChevronLeft, ChevronRight, Quote
} from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { toast } from 'sonner';

// Types
interface Testimonial {
  id: number;
  name: string;
  location: string;
  rating: number;
  text: string;
}

interface Blueprint {
  id: number;
  title: string;
  description: string;
}

interface FAQ {
  question: string;
  answer: string;
}

// Data
const testimonials: Testimonial[] = [
  {
    id: 1,
    name: "Priya S.",
    location: "Mumbai",
    rating: 5,
    text: "Using Blueprint 3 (Service Arbitrage), I landed my first ₹45,000 client in 3 weeks. The scripts in Chapter 6 were exactly what I needed to close the deal."
  },
  {
    id: 2,
    name: "Aman Sharma",
    location: "Bengaluru",
    rating: 5,
    text: "The mindset chapters alone are worth 10x the price. I stopped chasing shiny objects and started building a real system. The clarity this blueprint provides is priceless."
  },
  {
    id: 3,
    name: "Rohan V.",
    location: "Delhi",
    rating: 5,
    text: "No fluff, no BS. A real, actionable guide for the Indian market. The Service Arbitrage model was exactly what I needed to break through my initial income ceiling."
  },
  {
    id: 4,
    name: "Sameer Tambe",
    location: "Pune",
    rating: 4,
    text: "I mainly bought this for the E-commerce blueprint, but the Zero Inventory T-Shirt Brand chapter was the surprise winner. Already have my first 10 sales!"
  },
  {
    id: 5,
    name: "Kavya R.",
    location: "Hyderabad",
    rating: 5,
    text: "The step-by-step 6-month plan is a game-changer. It converts those 'I have an idea' moments into a solid, measurable path to ₹1 Lakh/month."
  },
  {
    id: 6,
    name: "Nikhil M.",
    location: "Chennai",
    rating: 4,
    text: "The biggest takeaway was the shift in my mindset—that I don't need huge capital to start. It taught me how to leverage my existing skills into pure profit streams."
  }
];

const blueprints: Blueprint[] = [
  {
    id: 1,
    title: "Your First ₹2L/Month E-Com Store",
    description: "Find a product on IndiaMart, sell it on Instagram. I'll show you the exact math that made me ₹2 Lakhs/month as a teenager."
  },
  {
    id: 2,
    title: "Build a T-Shirt Brand With Zero Inventory",
    description: "Use AI to create viral designs and Print-on-Demand to handle all printing & shipping. Sell a culture, not just a t-shirt."
  },
  {
    id: 3,
    title: "Earn ₹50k Commissions (With 0% Risk)",
    description: "Connect online leads to local property dealers for a high 50/50 commission split. One deal can be ₹50,000."
  },
  {
    id: 4,
    title: "Get Paid to Play (The Right Way)",
    description: "Stop just playing, start performing. The key isn't being the best player; it's being the best entertainer."
  },
  {
    id: 5,
    title: "Turn Social Media Into a ₹50k/Post Business",
    description: "How I turned my journey from debt into a brand that pays ₹15k-₹50k for a single post. Your face is your fortune."
  },
  {
    id: 6,
    title: "The Pure-Profit Digital Product Model",
    description: "Package your skills into an ebook or course. No inventory, no shipping. The ultimate scalable business model."
  }
];

const faqs: FAQ[] = [
  {
    question: "Is this another 'get rich quick' scheme?",
    answer: "Absolutely not. This is a 'get rich smart' blueprint. 'Get rich quick' is a fantasy that leads to debt. I was <strong>₹32 Lakh in debt</strong> because I fell for those myths. This book focuses on real, gradual strategies to build <strong>sustainable, predictable income.</strong>"
  },
  {
    question: "How is this different from free content on YouTube?",
    answer: "Free content gives you scattered puzzle pieces. This ebook gives you the <strong>finished picture and the instruction manual.</strong> It's a battle-tested system designed to save you 5+ years of painful, expensive trial and error. You're not just buying information; <strong>you're buying a proven roadmap and speed.</strong>"
  },
  {
    question: "Is this REALLY for the Indian market?",
    answer: "<strong>100% Yes.</strong> Every example, every currency figure (INR), and every strategy is tailored for the Indian context. This isn't recycled Western advice. It's built by an Indian, for the Indian hustler."
  },
  {
    question: "How to start a business with 0 investment in India?",
    answer: "<strong>Yes. That is the entire point of this book.</strong> I started with less than zero (massive debt!). This book focuses exclusively on businesses you can launch with <strong>₹0 investment.</strong> Your biggest asset will be your time and your hunger to win."
  },
  {
    question: "How can I start a side hustle in India with a full time job?",
    answer: "This was designed for you. The system works in <strong>focused 2-hour blocks</strong> that you can fit into your evenings or weekends. Your 9-5 is your safety net while you build your escape route. <strong>This book shows you how to build the boat before you jump off the ship.</strong>"
  },
  {
    question: "What if I fail?",
    answer: "The old way of failing is catastrophic. The new way—the ZeroFundedHustle way—is to <strong>fail smart, small, and fast.</strong> The models are designed to have virtually zero financial risk, so you can test ideas without fear of losing your savings. The real failure is staying stuck in a job you hate for the next 40 years."
  },
  {
    question: "How quickly can I see results?",
    answer: "I can't promise you a specific income, but I can promise you a specific plan. If you follow the 6-month roadmap and put in <strong>consistent effort</strong>, seeing your first <strong>₹10,000-₹20,000 is a very realistic goal.</strong> From there, you scale."
  },
  {
    question: "What if I'm not a 'business person'?",
    answer: "Neither was I. I was just a guy who was desperate to get out of a financial hole. This book breaks down everything into simple, non-jargon steps. If you can follow a recipe, you can follow this blueprint."
  }
];

// Components
function Navbar() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { href: '#blueprints', label: 'Blueprints' },
    { href: '#proof', label: 'Proof' },
    { href: '#bonuses', label: 'Bonuses' },
    { href: '#reviews', label: 'Reviews' },
    { href: '#faq', label: 'FAQ' },
  ];

  return (
    <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
      isScrolled ? 'bg-navy-900/95 backdrop-blur-md border-b border-gray-800 py-3' : 'bg-transparent py-4'
    }`}>
      <div className="container-custom">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <a href="/" className="flex items-center">
            <span className="text-xl md:text-2xl font-bold tracking-tight">
              <span className="text-white">zero</span>
              <span className="text-emerald-600">funded</span>
              <span className="text-white">hustle</span>
            </span>
          </a>

          {/* Desktop Navigation */}
          <div className="hidden lg:flex items-center gap-8">
            {navLinks.map((link) => (
              <a
                key={link.href}
                href={link.href}
                className="text-gray-300 hover:text-white text-sm font-medium transition-colors"
              >
                {link.label}
              </a>
            ))}
          </div>

          {/* CTA Button */}
          <div className="hidden lg:block">
            <a
              href="https://u.payu.in/nIsRdQdIBGDX"
              target="_blank"
              rel="noopener noreferrer"
              className="btn-primary text-sm"
            >
              Get Access (₹499)
            </a>
          </div>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            className="lg:hidden text-white p-2"
            aria-label="Toggle menu"
          >
            {isMobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>

        {/* Mobile Menu */}
        {isMobileMenuOpen && (
          <div className="lg:hidden mt-4 pb-4 border-t border-gray-800 pt-4 animate-fade-in">
            <div className="flex flex-col gap-4">
              {navLinks.map((link) => (
                <a
                  key={link.href}
                  href={link.href}
                  onClick={() => setIsMobileMenuOpen(false)}
                  className="text-gray-300 hover:text-emerald-600 text-sm font-medium transition-colors"
                >
                  {link.label}
                </a>
              ))}
              <a
                href="https://u.payu.in/nIsRdQdIBGDX"
                target="_blank"
                rel="noopener noreferrer"
                className="btn-primary text-sm mt-2"
              >
                Get Access (₹499)
              </a>
            </div>
          </div>
        )}
      </div>
    </nav>
  );
}

function Hero() {
  return (
    <section className="relative min-h-screen flex items-center pt-20 pb-16 overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-b from-navy-800 via-navy-900 to-navy-900" />
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[600px] bg-emerald-600/5 rounded-full blur-3xl" />
      
      <div className="container-custom relative z-10">
        <div className="max-w-4xl mx-auto text-center">
          {/* Badge */}
          <div className="inline-flex items-center gap-2 bg-navy-800/80 border border-gray-700 rounded-full px-4 py-2 mb-8 animate-fade-in-up">
            <span className="w-2 h-2 bg-emerald-600 rounded-full animate-pulse" />
            <span className="text-gray-300 text-xs font-bold tracking-wide uppercase">
              Zero-Risk Side Hustle Blueprint
            </span>
          </div>

          {/* Headline */}
          <h1 className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-bold text-white mb-6 leading-tight animate-fade-in-up stagger-1">
            Escape Your 9-5:{' '}
            <span className="gradient-text">Build a ₹50K/Month</span>{' '}
            Side Business With Zero Investment
          </h1>

          {/* Subheadline */}
          <div className="animate-fade-in-up stagger-2">
            <p className="text-gray-300 text-lg md:text-xl mb-2">
              From <span className="text-red-400 line-through">₹32 Lakh Debt</span> &{' '}
              <span className="text-gray-400">₹27k/mo</span> →{' '}
              <span className="text-emerald-600 font-bold">+₹5 Lakh/Month</span>
            </p>
            <p className="text-gray-400 text-base md:text-lg max-w-2xl mx-auto leading-relaxed mb-10">
              The zero-risk blueprint for building a real side business that replaces your income, 
              even if you have no time, no money, and no experience.
            </p>
          </div>

          {/* CTAs */}
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center animate-fade-in-up stagger-3">
            <a
              href="https://u.payu.in/nIsRdQdIBGDX"
              target="_blank"
              rel="noopener noreferrer"
              className="btn-primary text-base w-full sm:w-auto"
            >
              Get The Blueprint (₹499)
              <ArrowRight size={18} />
            </a>
            <a
              href="#lead-magnet"
              className="btn-secondary text-base w-full sm:w-auto"
            >
              <BookOpen size={18} />
              Get Free Chapter
            </a>
          </div>

          {/* Social Proof */}
          <div className="mt-12 pt-8 border-t border-gray-800/50 animate-fade-in-up stagger-4">
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <div className="flex -space-x-3">
                {[1, 2, 3].map((i) => (
                  <div
                    key={i}
                    className="w-10 h-10 rounded-full bg-gradient-to-br from-emerald-500 to-emerald-700 border-2 border-navy-900 flex items-center justify-center text-white text-xs font-bold"
                  >
                    {String.fromCharCode(64 + i)}
                  </div>
                ))}
              </div>
              <div className="text-white font-bold text-sm flex items-center gap-2">
                <Check className="text-emerald-600" size={18} />
                <span>2,900+ Hustlers Have Escaped</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

function TrustBanner() {
  const items = [
    { icon: Shield, text: '100% Secure Payment' },
    { icon: Lock, text: 'SSL Encrypted' },
    { icon: RotateCcw, text: '14-Day Money-Back Guarantee' },
    { icon: Download, text: 'Instant Digital Delivery' },
  ];

  return (
    <section className="bg-white py-6 border-y border-gray-100">
      <div className="container-custom">
        <div className="flex flex-wrap justify-center items-center gap-6 md:gap-8">
          {items.map((item, index) => (
            <div key={index} className="flex items-center gap-2">
              <div className="w-8 h-8 bg-emerald-50 rounded-full flex items-center justify-center">
                <item.icon className="text-emerald-600" size={16} />
              </div>
              <span className="text-gray-600 text-sm font-medium">{item.text}</span>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function ScrollingTicker() {
  const items = [
    { icon: TrendingUp, text: 'From ₹32L Debt → To ₹5L/Month' },
    { icon: Target, text: 'Escape 9-5 Cage' },
    { icon: Lightbulb, text: '6 Proven Methods' },
    { icon: Calendar, text: '6-Month Action Plan' },
    { icon: Zap, text: '₹0 to ₹50K/Month' },
    { icon: Shield, text: 'Zero Risk' },
  ];

  return (
    <div className="bg-navy-900 border-y border-gray-800 py-4 overflow-hidden">
      <div className="flex animate-scroll-banner whitespace-nowrap">
        {[...items, ...items].map((item, index) => (
          <span key={index} className="mx-8 text-gray-400 text-sm font-bold uppercase tracking-widest flex items-center">
            <item.icon className="text-emerald-600 mr-2" size={16} />
            {item.text}
          </span>
        ))}
      </div>
    </div>
  );
}

function LeadMagnet() {
  const [email, setEmail] = useState('');
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !email.includes('@')) {
      toast.error('Please enter a valid email address');
      return;
    }
    
    setIsLoading(true);
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1500));
    setIsLoading(false);
    setIsSubmitted(true);
    toast.success('Your free chapters are on the way!');
  };

  return (
    <section id="lead-magnet" className="section-padding bg-navy-900 relative overflow-hidden">
      <div className="absolute inset-0 bg-emerald-600/5 pointer-events-none" />
      
      <div className="container-custom relative z-10">
        <div className="card-dark backdrop-blur-md p-8 md:p-12 lg:p-16 flex flex-col lg:flex-row items-center justify-between gap-12">
          <div className="lg:w-1/2">
            <span className="bg-emerald-600/20 text-emerald-600 text-xs font-bold px-3 py-1 rounded-full mb-4 inline-block">
              FREE PREVIEW
            </span>
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-4 leading-tight">
              Read the Blueprint Before You Buy
            </h2>
            <p className="text-gray-400 mb-8 leading-relaxed">
              Get <strong>Chapter 1: The 9-5 Trap</strong> and <strong>Chapter 6: The E-commerce Hustle</strong>{' '}
              sent directly to your inbox for free. See the quality for yourself.
            </p>
            <ul className="space-y-3 text-gray-300 text-sm">
              <li className="flex items-center gap-3">
                <div className="bg-emerald-600/20 p-1 rounded-full">
                  <Check className="text-emerald-600" size={14} />
                </div>
                The essential mindset shift
              </li>
              <li className="flex items-center gap-3">
                <div className="bg-emerald-600/20 p-1 rounded-full">
                  <Check className="text-emerald-600" size={14} />
                </div>
                One complete, zero-cost business blueprint
              </li>
            </ul>
          </div>

          <div className="lg:w-1/2 w-full max-w-md">
            <div className="bg-navy-900 p-6 rounded-2xl border border-gray-700 glow-border">
              {!isSubmitted ? (
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div>
                    <Label htmlFor="lead-email" className="text-gray-400 text-xs font-bold uppercase tracking-wide">
                      Email Address
                    </Label>
                    <Input
                      id="lead-email"
                      type="email"
                      placeholder="Enter your best email..."
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="w-full bg-navy-800 border-gray-600 text-white placeholder:text-gray-500 focus:border-emerald-600 focus:ring-emerald-600 mt-2"
                      required
                    />
                  </div>
                  <button
                    type="submit"
                    disabled={isLoading}
                    className="w-full bg-white text-navy-900 font-bold rounded-xl px-5 py-4 hover:bg-emerald-600 hover:text-navy-900 transition-all shadow-md disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    {isLoading ? 'Sending...' : 'Send My Free Chapters'}
                  </button>
                  <p className="text-center text-xs text-gray-500">
                    We respect your privacy. No spam, ever.
                  </p>
                </form>
              ) : (
                <div className="flex flex-col items-center justify-center py-8 text-center animate-fade-in-up">
                  <div className="w-16 h-16 bg-emerald-600/20 rounded-full flex items-center justify-center mb-4">
                    <Check className="text-3xl text-emerald-600" size={32} />
                  </div>
                  <h3 className="text-xl font-bold text-white mb-2">Your request has been submitted!</h3>
                  <p className="text-gray-400 text-sm">
                    If you don't receive the chapters within 5 minutes, check your spam folder.
                  </p>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

function PainPoints() {
  const pains = [
    { icon: Calendar, title: 'Salary Gone by the 15th?', desc: 'Living paycheck to paycheck, watching your money disappear before the month ends.' },
    { icon: TriangleAlert, title: 'Fear of Expenses?', desc: 'Do you live in constant fear of one unexpected bill wrecking your entire month?' },
    { icon: Briefcase, title: 'Is Your Job a Cage?', desc: 'Does the thought of being in the same job 5 years from now terrify you?' },
    { icon: Eye, title: 'Watching Others Win?', desc: 'Tired of watching others succeed online while you are stuck on the sidelines?' },
    { icon: Lightbulb, title: 'Ideas but No Clue?', desc: 'Have great ideas but absolutely no clue where to actually start?' },
  ];

  return (
    <section className="section-padding bg-white">
      <div className="container-custom">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-navy-900 mb-4">
            Are You Feeling Trapped?
          </h2>
          <p className="text-gray-500">
            If you are nodding your head to any of these questions, you are not alone.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {pains.map((pain, index) => (
            <div
              key={index}
              className="card-light p-8 hover:border-red-200 hover:shadow-card-hover transition-all group"
            >
              <div className="w-12 h-12 bg-red-50 text-red-500 rounded-xl flex items-center justify-center mb-6 text-xl group-hover:bg-red-500 group-hover:text-white transition-colors">
                <pain.icon size={24} />
              </div>
              <h3 className="font-bold text-navy-900 text-lg mb-3">{pain.title}</h3>
              <p className="text-gray-500 text-sm leading-relaxed">{pain.desc}</p>
            </div>
          ))}
          
          {/* CTA Card */}
          <div className="card-light p-8 flex flex-col items-center justify-center text-center bg-navy-900 border-navy-800">
            <p className="font-bold text-white mb-6 text-xl">Yes, That is Me.</p>
            <a
              href="https://u.payu.in/nIsRdQdIBGDX"
              target="_blank"
              rel="noopener noreferrer"
              className="bg-white text-navy-900 text-sm font-bold px-8 py-4 rounded-xl hover:bg-gray-100 transition-all shadow-lg w-full text-center flex items-center justify-center gap-2"
            >
              I Need A Plan
              <ArrowRight size={16} />
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}

function AudienceFilter() {
  return (
    <section id="audience-filter" className="section-padding bg-white overflow-hidden">
      <div className="container-custom">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-navy-900 mb-4">
            Who Is This For?
          </h2>
          <p className="text-gray-500 text-lg">
            This book only works if you do the work. Be honest with yourself.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-8 items-stretch">
          {/* For You */}
          <div className="bg-emerald-50 border-2 border-emerald-200 rounded-3xl p-8 md:p-12 relative overflow-hidden">
            <div className="absolute top-0 left-0 w-full h-2 bg-emerald-600" />
            <h3 className="text-2xl font-bold text-navy-900 mb-8 flex items-center gap-3">
              <div className="w-10 h-10 bg-emerald-600 text-white rounded-full flex items-center justify-center">
                <Check size={20} />
              </div>
              This Is For You If...
            </h3>
            <div className="space-y-6">
              {[
                'You are currently in debt or living paycheck-to-paycheck.',
                'You have 1-2 hours a day to dedicate to your hustle.',
                'You are tired of theory and need a step-by-step plan.',
              ].map((item, index) => (
                <div key={index} className="flex gap-4 items-start">
                  <div className="w-6 h-6 mt-1 bg-emerald-600 text-white rounded-full flex items-center justify-center flex-shrink-0 text-xs">
                    <Check size={12} />
                  </div>
                  <p className="text-navy-900 font-medium">{item}</p>
                </div>
              ))}
            </div>
            
            {/* Visual Card */}
            <div className="mt-8 pt-4 border-t border-emerald-200">
              <div className="w-full rounded-2xl overflow-hidden shadow-xl bg-gradient-to-r from-emerald-600 to-emerald-400">
                <div className="p-6 bg-navy-900/90 backdrop-blur-sm">
                  <div className="flex justify-between items-center mb-4">
                    <CreditCard className="text-emerald-600" size={24} />
                    <span className="bg-emerald-600 text-navy-900 text-xs font-bold px-3 py-1 rounded-full">
                      Pro Hustler
                    </span>
                  </div>
                  <p className="text-gray-400 text-sm uppercase font-semibold mb-1">Goal Status</p>
                  <h4 className="text-3xl font-bold text-white mb-6">Financial Freedom</h4>
                  <div className="space-y-3 p-4 bg-gray-800/50 rounded-xl border border-gray-700">
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-400">Debt</span>
                      <span className="font-bold text-emerald-400">₹0.00</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-400">Income Sources</span>
                      <span className="font-bold text-emerald-600">6 Active</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="mt-8 text-center">
              <a
                href="https://u.payu.in/nIsRdQdIBGDX"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 bg-emerald-600 text-navy-900 font-bold py-3 px-8 rounded-full hover:bg-emerald-500 transition-all shadow-lg text-sm"
              >
                I am Ready To Hustle
                <ArrowRight size={16} />
              </a>
            </div>
          </div>

          {/* Not For You */}
          <div className="bg-red-50 border-2 border-red-100 rounded-3xl p-8 md:p-12 relative overflow-hidden">
            <div className="absolute top-0 left-0 w-full h-2 bg-red-400" />
            <h3 className="text-2xl font-bold text-navy-900 mb-8 flex items-center gap-3">
              <div className="w-10 h-10 bg-red-100 text-red-500 rounded-full flex items-center justify-center">
                <X size={20} />
              </div>
              This Is Not For You If...
            </h3>
            <div className="space-y-6">
              {[
                'You want "get rich quick" schemes without effort.',
                'You are unwilling to learn basic digital skills.',
                'You expect to make ₹1 Lakh by Friday doing nothing.',
              ].map((item, index) => (
                <div key={index} className="flex gap-4 items-start">
                  <div className="w-6 h-6 mt-1 bg-red-100 text-red-500 rounded-full flex items-center justify-center flex-shrink-0 text-xs">
                    <X size={12} />
                  </div>
                  <p className="text-navy-900 font-medium opacity-80">{item}</p>
                </div>
              ))}
            </div>

            {/* Visual Card */}
            <div className="mt-8 pt-4 border-t border-red-200">
              <div className="w-full rounded-2xl overflow-hidden shadow-xl bg-red-100 border-2 border-red-300">
                <div className="p-6">
                  <div className="flex justify-between items-center mb-4">
                    <Clock className="text-red-500" size={24} />
                    <span className="bg-red-400 text-white text-xs font-bold px-3 py-1 rounded-full">
                      Dreamer Status
                    </span>
                  </div>
                  <p className="text-red-700 text-sm uppercase font-semibold mb-1">Reality Status</p>
                  <h4 className="text-3xl font-bold text-red-900 mb-6">Fantasy Status</h4>
                  <div className="space-y-3 p-4 bg-red-50 rounded-xl border border-red-200">
                    <div className="flex justify-between text-sm">
                      <span className="text-red-700">Effort Invested</span>
                      <span className="font-bold text-red-600">0 hours</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-red-700">Total Revenue</span>
                      <span className="font-bold text-red-600">₹0.00</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="mt-8 text-center">
              <a
                href="#faq"
                className="inline-flex items-center gap-2 bg-red-500 text-white font-bold py-3 px-8 rounded-full hover:bg-red-600 transition-all shadow-lg text-sm"
              >
                I Need to Ask a Question
                <ArrowRight size={16} />
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

function Personas() {
  const personas = [
    {
      icon: Minus,
      color: 'red',
      title: 'The Employee in Debt',
      desc: 'Stuck in a loop of EMIs and monthly bills? This is your structured way out.'
    },
    {
      icon: Sun,
      color: 'yellow',
      title: 'The Silent Hustler',
      desc: 'Grinding after work with no clear direction? This converts your extra hours into consistent income.'
    },
    {
      icon: GraduationCap,
      color: 'blue',
      title: 'The Ambitious Student',
      desc: 'Done with theory that leads nowhere? Think of this as your practical crash-course in launching a real business.'
    },
  ];

  const colorClasses: Record<string, { border: string; icon: string; shadow: string }> = {
    red: { border: 'hover:border-red-500/50', icon: 'text-red-500 border-red-500', shadow: 'shadow-red-500/20 hover:shadow-red-500/40' },
    yellow: { border: 'hover:border-yellow-400/50', icon: 'text-yellow-400 border-yellow-400', shadow: 'shadow-yellow-400/20 hover:shadow-yellow-400/40' },
    blue: { border: 'hover:border-blue-500/50', icon: 'text-blue-500 border-blue-500', shadow: 'shadow-blue-500/20 hover:shadow-blue-500/40' },
  };

  return (
    <section className="section-padding bg-navy-900">
      <div className="container-custom">
        <h2 className="text-3xl md:text-4xl font-bold text-center text-white mb-16 leading-tight">
          This is for the person who knows they are meant for more.
        </h2>
        
        <div className="grid md:grid-cols-3 gap-8">
          {personas.map((persona, index) => (
            <div
              key={index}
              className={`card-dark p-8 text-center group ${colorClasses[persona.color].border} transition-all transform hover:-translate-y-2 duration-300`}
            >
              <div className={`w-16 h-16 mx-auto bg-navy-900 rounded-full border-2 flex items-center justify-center mb-6 shadow-lg ${colorClasses[persona.color].icon} ${colorClasses[persona.color].shadow} transition-all`}>
                <persona.icon size={28} />
              </div>
              <h3 className="text-xl font-bold text-white mb-4">{persona.title}</h3>
              <p className="text-gray-400 text-sm leading-relaxed">{persona.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function Mentor() {
  return (
    <section className="section-padding bg-gray-50">
      <div className="container-custom">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          <div>
            <span className="text-emerald-700 font-bold tracking-widest uppercase text-xs mb-2 block">
              Meet Your Mentor
            </span>
            <h2 className="text-3xl md:text-4xl font-bold text-navy-900 mb-6 leading-tight">
              From <span className="text-red-500">₹32 Lakhs Debt</span> to{' '}
              <span className="text-emerald-600">+₹5 Lakh/Month</span>
            </h2>
            <div className="space-y-4 text-gray-600 leading-relaxed">
              <p>
                I am Harshdeep Singh. I am not a guru. My story is messy, painful, and 100% real.
              </p>
              <p>
                At 15, I was earning ₹2 Lakhs/month. By 18, I was <strong>₹32 Lakhs in debt</strong>{' '}
                due to lifestyle inflation. My ₹27k/month job could not even cover the interest.
              </p>
              <p>
                Rock bottom was not the debt; it was the realization that the traditional path would never save me. 
                I needed a new way—a way to build wealth without capital I did not have.
              </p>
              <p>
                This book is the blueprint I used to not only clear every rupee of that debt, 
                but build a system of zero-funded businesses that now generate a consistent ₹5 Lakh/month.
              </p>
              <div className="bg-white p-4 rounded-xl border-l-4 border-emerald-600 shadow-sm mt-4">
                <p className="italic text-navy-900 font-medium">
                  "I am not here to sell you dreams. I am here to give you the exact, battle-tested blueprint 
                  I used to escape my financial prison."
                </p>
              </div>
            </div>
          </div>
          
          <div className="relative group">
            <div className="bg-navy-900 rounded-[40px] p-2 shadow-2xl transform rotate-2 group-hover:rotate-0 transition-transform duration-500">
              <div className="rounded-[32px] w-full aspect-[4/3] bg-gradient-to-br from-emerald-600/20 to-navy-800 flex items-center justify-center overflow-hidden">
                <div className="text-center p-8">
                  <div className="w-24 h-24 mx-auto bg-emerald-600/20 rounded-full flex items-center justify-center mb-4">
                    <TrendingUp className="text-emerald-600" size={48} />
                  </div>
                  <p className="text-white font-bold text-lg">Harshdeep Singh</p>
                  <p className="text-gray-400 text-sm">Founder, ZeroFundedHustle</p>
                </div>
              </div>
            </div>
            <div className="absolute bottom-10 -left-6 bg-white p-4 rounded-xl shadow-lg flex items-center gap-3 transition-transform duration-500 group-hover:scale-105">
              <div className="bg-emerald-600 text-white w-10 h-10 rounded-full flex items-center justify-center font-bold">
                <Check size={20} />
              </div>
              <div>
                <p className="text-xs text-gray-500 font-bold uppercase">Result</p>
                <p className="font-bold text-navy-900">100% Debt Free</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

function TransitionBanner() {
  return (
    <section className="py-16 bg-navy-900 border-y border-gray-800 relative overflow-hidden">
      <div className="absolute top-0 left-0 w-full h-full bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-emerald-600/10 via-navy-900 to-navy-900 opacity-50" />
      
      <div className="container-custom text-center relative z-10">
        <div className="inline-flex items-center justify-center gap-3 mb-4">
          <div className="h-px w-12 bg-gray-600" />
          <span className="text-emerald-600 text-xs font-bold uppercase tracking-[0.2em]">Reality Check</span>
          <div className="h-px w-12 bg-gray-600" />
        </div>
        <h3 className="text-2xl md:text-3xl font-bold text-white leading-relaxed max-w-4xl mx-auto">
          Do not let another year pass stuck in the same spot. 
          <span className="block mt-2">
            The only thing standing between you and freedom is a{' '}
            <span className="text-emerald-600 border-b-2 border-emerald-600">proven plan</span>.
          </span>
        </h3>
      </div>
    </section>
  );
}

function IncomeProof() {
  return (
    <section id="proof" className="section-padding bg-white">
      <div className="container-custom">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-navy-900 mb-4">
            The Numbers Do not Lie
          </h2>
          <p className="text-gray-500 max-w-xl mx-auto">
            The brutal financial reality I left behind, and the consistent income I built.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {/* Debt Card */}
          <div className="card-dark p-8 text-white relative overflow-hidden border-2 border-red-500 group hover:-translate-y-1 transition-transform">
            <h3 className="text-xl font-bold mb-2 text-red-400">Max Debt Incurred</h3>
            <p className="text-gray-400 text-sm mb-8">Starting Point</p>
            <div className="mt-4">
              <span className="text-4xl font-bold text-white">-₹32L</span>
              <span className="text-xs text-gray-400 block mt-2">Paid off completely</span>
            </div>
          </div>

          {/* Salary Cap Card */}
          <div className="card-light p-8 flex flex-col items-center justify-center border-2 border-emerald-600/50 group hover:-translate-y-1 transition-transform">
            <h3 className="text-xl font-bold text-navy-900 text-center mb-2">Old Salary Cap</h3>
            <p className="text-gray-500 text-xs text-center mb-4">The cage I was tied to.</p>
            <div className="relative w-32 h-32 flex items-center justify-center border-4 border-gray-100 rounded-full">
              <div className="text-center">
                <span className="text-2xl font-bold text-navy-900">₹27k</span>
                <span className="block text-[10px] uppercase text-gray-400">Per Month</span>
              </div>
            </div>
          </div>

          {/* Current Income Card */}
          <div className="card-light p-8 border-2 border-emerald-600 group hover:-translate-y-1 transition-transform">
            <h3 className="text-xl font-bold text-navy-900 mb-2">Current Income</h3>
            <p className="text-gray-500 text-sm mb-10">Zero-investment systems.</p>
            <div className="bg-gray-50 rounded-2xl p-4 mb-4">
              <p className="text-xs text-gray-400 mb-1">Monthly Revenue</p>
              <div className="flex justify-between items-center">
                <span className="text-2xl font-bold text-navy-900">+₹5L/mo</span>
                <div className="bg-emerald-600 text-navy-900 text-xs font-bold px-2 py-1 rounded-md">
                  18x Growth
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="mt-12 text-center">
          <a
            href="https://u.payu.in/nIsRdQdIBGDX"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 bg-navy-900 text-white font-bold py-4 px-10 rounded-full hover:bg-gray-800 transition-all shadow-lg"
          >
            I Want This Financial Freedom
            <ArrowRight className="text-emerald-600" size={18} />
          </a>
        </div>
      </div>
    </section>
  );
}

function Pillars() {
  const pillars = [
    {
      icon: Zap,
      title: "Pillar 1: The 'Zero-Risk' Mindset",
      desc: "Most people only see risk. We see <strong>zero-cost opportunity</strong>. Focus on leveraging existing, free tools and services to validate demand *before* investing a rupee."
    },
    {
      icon: Cog,
      title: "Pillar 2: System Over Income",
      desc: "Your job pays you for hours. Your hustle must pay you for <strong>systems</strong>. Build automated income streams that run while you sleep or work your 9-5."
    },
    {
      icon: ChartLine,
      title: "Pillar 3: The Profit Layering Model",
      desc: "Never rely on one income stream. The key is <strong>layering</strong> small, zero-cost hustles so your combined income creates the financial cushion you need to quit."
    },
  ];

  return (
    <section className="section-padding bg-navy-900">
      <div className="container-custom">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
            The 3 Pillars of Zero-Funded Hustling
          </h2>
          <p className="text-gray-400 text-lg">
            Before the strategy, you need the foundation. These are the core tenets that separate 
            the 9-5 employee from the entrepreneur.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {pillars.map((pillar, index) => (
            <div
              key={index}
              className="card-dark p-8 hover:border-emerald-600/50 transition-all group"
            >
              <div className="w-12 h-12 bg-emerald-600/20 text-emerald-600 rounded-xl flex items-center justify-center mb-4 text-xl">
                <pillar.icon size={24} />
              </div>
              <h3 className="font-bold text-white text-xl mb-2">{pillar.title}</h3>
              <p className="text-gray-400 text-sm leading-relaxed" dangerouslySetInnerHTML={{ __html: pillar.desc }} />
            </div>
          ))}
        </div>

        <div className="mt-16 text-center">
          <a
            href="https://u.payu.in/nIsRdQdIBGDX"
            target="_blank"
            rel="noopener noreferrer"
            className="btn-primary text-lg"
          >
            Build My Foundation (₹499)
            <ArrowRight size={18} />
          </a>
        </div>
      </div>
    </section>
  );
}

function Blueprints() {
  return (
    <section id="blueprints" className="section-padding bg-white">
      <div className="container-custom">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-navy-900 mb-4">
            A Glimpse Inside Your Blueprint
          </h2>
          <p className="text-gray-500 text-lg">
            This is not theory. It is a toolbox of <strong>6 proven, step-by-step models</strong>{' '}
            I have personally used to build real income streams from scratch.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {blueprints.map((blueprint, index) => (
            <div
              key={blueprint.id}
              className="card-dark p-8 hover:border-emerald-600/50 transition-all group hover:-translate-y-1"
              style={{ animationDelay: `${index * 100}ms` }}
            >
              <h3 className="font-bold text-white text-xl mb-3">{blueprint.title}</h3>
              <p className="text-gray-400 text-sm leading-relaxed">{blueprint.description}</p>
            </div>
          ))}
        </div>

        <div className="mt-16 text-center">
          <a
            href="https://u.payu.in/nIsRdQdIBGDX"
            target="_blank"
            rel="noopener noreferrer"
            className="btn-primary text-lg"
          >
            See All 6 Blueprints Inside (₹499)
            <ArrowRight size={18} />
          </a>
        </div>
      </div>
    </section>
  );
}

function ProductBenefits() {
  const benefits = [
    { icon: ListChecks, title: '6 Blueprints to Earn ₹50k-₹150k', desc: 'Copy-paste models with real math.' },
    { icon: Wallet, title: 'Start With ₹0 Investment', desc: 'Your bank balance does not define potential.' },
    { icon: Shield, title: 'Build a Financial Safety Net', desc: 'Secure your future with multiple streams.' },
    { icon: MapPin, title: 'Roadmap to ₹100k/Month', desc: 'Day-by-day plan from Chapter 9.' },
    { icon: RefreshCw, title: 'Free Lifetime Updates', desc: 'Digital world changes fast. You get updates.' },
    { icon: Mail, title: 'Direct Email Support', desc: 'Personal help to guide you through hurdles.' },
  ];

  return (
    <section className="section-padding bg-white">
      <div className="container-custom">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-navy-900 mb-4">
            This Is More Than an Ebook. It is Your New Reality.
          </h2>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {benefits.map((benefit, index) => (
            <div
              key={index}
              className="card-light p-8 hover:shadow-card-hover transition-all"
            >
              <div className="w-12 h-12 bg-emerald-600/20 rounded-xl flex items-center justify-center mb-4 text-navy-900">
                <benefit.icon size={24} />
              </div>
              <h3 className="text-xl font-bold text-navy-900 mb-2">{benefit.title}</h3>
              <p className="text-gray-500 text-sm">{benefit.desc}</p>
            </div>
          ))}
        </div>

        <div className="mt-16 text-center">
          <a
            href="https://u.payu.in/nIsRdQdIBGDX"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 bg-navy-900 text-white font-bold py-4 px-10 rounded-full hover:bg-gray-800 transition-all shadow-lg"
          >
            Build Your New Reality Today
            <ArrowRight className="text-emerald-600" size={18} />
          </a>
        </div>
      </div>
    </section>
  );
}

function Mistakes() {
  const mistakes = [
    { icon: TrendingDown, title: 'Never Tracking Money', desc: 'I made ₹2L/month but had <20k left. I was making money but not building wealth. A fool is game.' },
    { icon: CreditCard, title: 'Emotional Spending', desc: 'Stressed? I would buy a ₹15,000 watch. The thrill was temporary, but the guilt and bill were permanent.' },
    { icon: TrendingUp, title: 'Lifestyle Inflation', desc: 'As income went up, so did spending. I was running on a financial treadmill, never getting ahead.' },
    { icon: Wallet, title: 'Treating Debt Like Magic Money', desc: 'Credit cards felt like superpowers. I paid ₹15,000 in extra interest just for the privilege of owning a phone immediately.' },
    { icon: ChartLine, title: 'Not Investing Early', desc: 'I thought investing was for rich people. I lost 7 priceless years of compound growth.' },
  ];

  return (
    <section className="section-padding bg-navy-900">
      <div className="container-custom">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
            I Made the Mistakes So You Do not Have To
          </h2>
          <p className="text-gray-400">
            My ₹32 Lakh debt was an expensive education. Here is the wisdom I bought with those failures.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {mistakes.map((mistake, index) => (
            <div
              key={index}
              className="card-dark p-8 hover:border-red-500/50 transition-colors"
            >
              <div className="w-12 h-12 bg-red-500/10 rounded-xl flex items-center justify-center mb-4">
                <mistake.icon className="text-red-500" size={24} />
              </div>
              <h3 className="text-xl font-bold text-white mb-2">{mistake.title}</h3>
              <p className="text-gray-400 text-sm" dangerouslySetInnerHTML={{ __html: mistake.desc }} />
            </div>
          ))}
          
          {/* CTA Card */}
          <div className="card-dark p-8 flex flex-col items-center justify-center text-center border-emerald-600/50 hover:border-emerald-600 transition-colors">
            <p className="font-bold text-white mb-6 text-xl">I Do not Want to Make a Mistake.</p>
            <a
              href="https://u.payu.in/nIsRdQdIBGDX"
              target="_blank"
              rel="noopener noreferrer"
              className="bg-emerald-600 text-navy-900 text-sm font-bold px-8 py-4 rounded-xl hover:bg-emerald-500 transition-all shadow-lg w-full text-center flex items-center justify-center gap-2"
            >
              Start Your Journey
              <ArrowRight size={16} />
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}

function ComparisonTable() {
  const rows = [
    { feature: 'Price', this: '₹499', other: '₹5,000-₹50,000' },
    { feature: 'Zero Investment Models', this: true, other: false },
    { feature: 'India-Specific Strategies', this: true, other: false },
    { feature: 'Step-by-Step 6-Month Plan', this: true, other: 'Generic advice' },
    { feature: 'Lifetime Updates', this: true, other: false },
    { feature: 'Direct Email Support', this: true, other: 'Community forums only' },
  ];

  return (
    <section className="section-padding bg-gray-50 border-t border-gray-200">
      <div className="container-custom">
        <h2 className="text-3xl md:text-4xl font-bold text-center text-navy-900 mb-12">
          Why This Blueprint vs. Expensive Courses?
        </h2>
        
        <div className="max-w-4xl mx-auto bg-white rounded-2xl shadow-lg overflow-hidden border border-gray-200">
          <table className="w-full">
            <thead className="bg-navy-900 text-white">
              <tr>
                <th className="py-5 px-6 text-left text-sm md:text-base">Feature</th>
                <th className="py-5 px-6 text-center text-sm md:text-base bg-navy-800">This Blueprint</th>
                <th className="py-5 px-6 text-center text-sm md:text-base text-gray-400">Other Courses</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {rows.map((row, index) => (
                <tr key={index}>
                  <td className="py-4 px-6 font-medium text-navy-900">{row.feature}</td>
                  <td className="py-4 px-6 text-center bg-gray-50">
                    {typeof row.this === 'boolean' ? (
                      row.this ? <Check className="text-emerald-600 mx-auto" size={24} /> : <X className="text-red-500 mx-auto" size={24} />
                    ) : (
                      <span className="text-emerald-600 font-bold">{row.this}</span>
                    )}
                  </td>
                  <td className="py-4 px-6 text-center text-gray-500">
                    {typeof row.other === 'boolean' ? (
                      row.other ? <Check className="text-emerald-600 mx-auto" size={24} /> : <X className="text-red-500 mx-auto" size={24} />
                    ) : (
                      row.other
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="mt-12 text-center">
          <a
            href="https://u.payu.in/nIsRdQdIBGDX"
            target="_blank"
            rel="noopener noreferrer"
            className="btn-primary text-lg"
          >
            Choose The ₹499 Blueprint
            <ArrowRight size={18} />
          </a>
        </div>
      </div>
    </section>
  );
}

function Bonuses() {
  const bonuses = [
    { title: '7-Day Launchpad', value: '₹1,499', desc: 'A step-by-step checklist to launch your first Micro-Hustle in just one week.' },
    { title: 'Debt-Crusher Template', value: '₹999', desc: 'The exact spreadsheet I used to track spending and clear ₹32 Lakhs in debt.' },
    { title: 'Zero-Cost Tools Vault', value: '₹2,500', desc: '15+ free tools for marketing and design, so you can run all 6 blueprints with zero investment.' },
  ];

  return (
    <section id="bonuses" className="section-padding bg-white">
      <div className="container-custom text-center">
        <span className="bg-navy-900 text-white text-xs font-bold px-3 py-1 rounded-full mb-4 inline-block">
          INCLUDED TODAY
        </span>
        <h2 className="text-3xl md:text-4xl font-bold text-navy-900 mb-12">
          Get ₹4,997 Worth of Bonuses Free
        </h2>

        <div className="grid md:grid-cols-3 gap-8">
          {bonuses.map((bonus, index) => (
            <div
              key={index}
              className="bg-gray-50 p-8 rounded-2xl shadow-sm border-t-4 border-emerald-600"
            >
              <h3 className="font-bold text-xl text-navy-900 mb-2">{bonus.title}</h3>
              <p className="text-emerald-700 font-bold text-sm mb-4">Value: {bonus.value}</p>
              <p className="text-gray-500 text-sm">{bonus.desc}</p>
            </div>
          ))}
        </div>

        <div className="mt-12">
          <a
            href="https://u.payu.in/nIsRdQdIBGDX"
            target="_blank"
            rel="noopener noreferrer"
            className="btn-primary"
          >
            Yes, I want all these bonuses
            <Gift size={18} />
          </a>
        </div>
      </div>
    </section>
  );
}

function Timeline() {
  const stages = [
    { icon: Zap, title: 'Stage 1: Start Fast', mindset: 'Do not wait. Done is better than perfect.', action: 'Choose one blueprint and launch a minimal version using zero-cost tools.', goal: 'Get your first small win.' },
    { icon: Eye, title: 'Stage 2: Get Proof', mindset: 'What works once, can work again.', action: 'Improve your offer based on feedback. Get 1-3 paying customers and collect testimonials.', goal: 'Repeatable results & belief.' },
    { icon: Cog, title: 'Stage 3: Systemize', mindset: 'Consistency beats speed.', action: 'Define a weekly hustle routine. Implement simple checklists and templates to remove chaos and stress.', goal: 'Hustle consistently without stress.' },
    { icon: ChartLine, title: 'Stage 4: Scale Smart', mindset: 'Work smart, not harder.', action: 'Raise your prices, launch a high-value offer, or layer a second zero-funded blueprint.', goal: 'Sustainable income growth.' },
  ];

  return (
    <section id="timeline" className="section-padding bg-gray-50">
      <div className="container-custom">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-navy-900 mb-4">
            Your 4-Stage Escape Journey
          </h2>
          <p className="text-gray-500 text-lg">
            Forget monthly deadlines. This simplified roadmap works for all 6 blueprints, 
            focusing on the mindset and actions required for reliable growth.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 max-w-6xl mx-auto">
          {stages.map((stage, index) => (
            <div
              key={index}
              className="card-light p-8 hover:shadow-card-hover transition-all h-full flex flex-col"
            >
              <div className="w-12 h-12 bg-emerald-600/20 rounded-xl flex items-center justify-center mb-4 text-navy-900">
                <stage.icon size={24} />
              </div>
              <h3 className="text-xl font-bold text-navy-900 mb-2">{stage.title}</h3>
              <p className="text-gray-500 text-sm flex-grow">
                <strong>Mindset:</strong> {stage.mindset}<br />
                <strong>Action:</strong> {stage.action}
              </p>
              <p className="text-xs text-emerald-600 font-bold mt-3">Goal: {stage.goal}</p>
            </div>
          ))}
        </div>

        <div className="mt-16 text-center">
          <a
            href="https://u.payu.in/nIsRdQdIBGDX"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-block bg-navy-900 text-white font-bold py-4 px-10 rounded-full hover:bg-gray-800 transition-colors"
          >
            Start My Escape Journey Now
          </a>
        </div>
      </div>
    </section>
  );
}

function Testimonials() {
  const [currentIndex, setCurrentIndex] = useState(0);

  const next = () => {
    setCurrentIndex((prev) => (prev + 1) % testimonials.length);
  };

  const prev = () => {
    setCurrentIndex((prev) => (prev - 1 + testimonials.length) % testimonials.length);
  };

  return (
    <section id="reviews" className="section-padding bg-white">
      <div className="container-custom">
        <h2 className="text-3xl font-bold text-center text-navy-900 mb-16">
          Proof From People Like You
        </h2>

        <div className="relative max-w-4xl mx-auto">
          {/* Navigation Buttons */}
          <button
            onClick={prev}
            className="absolute left-0 -translate-x-4 lg:-translate-x-12 top-1/2 -translate-y-1/2 z-20 w-12 h-12 bg-white hover:bg-emerald-600 text-navy-900 rounded-full flex items-center justify-center shadow-lg transition-all"
            aria-label="Previous testimonial"
          >
            <ChevronLeft size={20} />
          </button>
          <button
            onClick={next}
            className="absolute right-0 translate-x-4 lg:translate-x-12 top-1/2 -translate-y-1/2 z-20 w-12 h-12 bg-white hover:bg-emerald-600 text-navy-900 rounded-full flex items-center justify-center shadow-lg transition-all"
            aria-label="Next testimonial"
          >
            <ChevronRight size={20} />
          </button>

          {/* Slider */}
          <div className="overflow-hidden rounded-3xl">
            <div 
              className="flex transition-transform duration-500 ease-out"
              style={{ transform: `translateX(-${currentIndex * 100}%)` }}
            >
              {testimonials.map((testimonial) => (
                <div
                  key={testimonial.id}
                  className="w-full flex-shrink-0 bg-navy-900 p-8 md:p-12 relative overflow-hidden"
                >
                  <Quote className="absolute top-8 right-8 text-6xl text-white/5" size={64} />
                  <div className="relative z-10 text-white">
                    <div className="flex gap-1 text-yellow-400 text-sm mb-4">
                      {[...Array(5)].map((_, i) => (
                        <Star
                          key={i}
                          size={16}
                          className={i < testimonial.rating ? 'fill-yellow-400' : 'text-gray-600'}
                        />
                      ))}
                    </div>
                    <p className="text-lg leading-relaxed italic font-light mb-6 opacity-90">
                      "{testimonial.text}"
                    </p>
                    <div className="border-t border-white/10 pt-6">
                      <h4 className="font-bold text-emerald-600 text-lg">{testimonial.name}</h4>
                      <p className="text-sm text-gray-400">{testimonial.location}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Dots */}
          <div className="flex justify-center mt-8 gap-2">
            {testimonials.map((_, index) => (
              <button
                key={index}
                onClick={() => setCurrentIndex(index)}
                className={`w-3 h-3 rounded-full transition-all ${
                  index === currentIndex ? 'bg-emerald-600 w-6' : 'bg-gray-300 hover:bg-gray-400'
                }`}
                aria-label={`Go to testimonial ${index + 1}`}
              />
            ))}
          </div>
        </div>

        <div className="mt-16 text-center">
          <a
            href="https://u.payu.in/nIsRdQdIBGDX"
            target="_blank"
            rel="noopener noreferrer"
            className="btn-primary text-lg"
          >
            I am Ready to Read the Reviews for Myself
            <ArrowRight size={18} />
          </a>
        </div>
      </div>
    </section>
  );
}

function ReviewForm() {
  const [isOpen, setIsOpen] = useState(false);
  const [rating, setRating] = useState(0);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (rating === 0) {
      toast.error('Please select a rating');
      return;
    }

    setIsLoading(true);
    await new Promise(resolve => setTimeout(resolve, 1500));
    setIsLoading(false);
    setIsSubmitted(true);
    toast.success('Thank you for your review!');
  };

  return (
    <section className="section-padding bg-navy-900">
      <div className="container-custom max-w-2xl">
        <div className="text-center mb-10">
          <h2 className="text-3xl font-bold text-white mb-6">Found Value? Share Your Story!</h2>
          <button
            onClick={() => setIsOpen(!isOpen)}
            className="btn-primary"
          >
            Share Your Experience
            <ChevronRight size={18} className={`transition-transform ${isOpen ? 'rotate-90' : ''}`} />
          </button>
        </div>

        {isOpen && !isSubmitted && (
          <div className="card-dark p-8 glow-border animate-fade-in">
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <Label htmlFor="review-name" className="text-gray-400 text-xs font-bold uppercase tracking-wide">
                  Name *
                </Label>
                <Input
                  id="review-name"
                  required
                  className="bg-navy-900 border-gray-600 text-white mt-2"
                  placeholder="Your Name"
                />
              </div>
              <div>
                <Label htmlFor="review-email" className="text-gray-400 text-xs font-bold uppercase tracking-wide">
                  Email *
                </Label>
                <Input
                  id="review-email"
                  type="email"
                  required
                  className="bg-navy-900 border-gray-600 text-white mt-2"
                  placeholder="your@email.com"
                />
              </div>
              <div>
                <Label className="text-gray-400 text-xs font-bold uppercase tracking-wide">
                  Rating *
                </Label>
                <div className="flex gap-2 mt-2">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <button
                      key={star}
                      type="button"
                      onClick={() => setRating(star)}
                      className="text-2xl transition-colors"
                    >
                      <Star
                        size={28}
                        className={star <= rating ? 'fill-yellow-400 text-yellow-400' : 'text-gray-600'}
                      />
                    </button>
                  ))}
                </div>
              </div>
              <div>
                <Label htmlFor="review-text" className="text-gray-400 text-xs font-bold uppercase tracking-wide">
                  Review *
                </Label>
                <Textarea
                  id="review-text"
                  required
                  rows={4}
                  className="bg-navy-900 border-gray-600 text-white mt-2"
                  placeholder="How has this helped you?"
                />
              </div>
              <button
                type="submit"
                disabled={isLoading}
                className="w-full bg-emerald-600 text-navy-900 font-bold py-3 rounded-xl hover:bg-emerald-500 transition-all disabled:opacity-50"
              >
                {isLoading ? 'Submitting...' : 'Submit My Review'}
              </button>
            </form>
          </div>
        )}

        {isSubmitted && (
          <div className="card-dark p-8 glow-border text-center animate-fade-in-up">
            <div className="w-16 h-16 bg-emerald-600/20 rounded-full flex items-center justify-center mx-auto mb-4">
              <Check className="text-3xl text-emerald-600" size={32} />
            </div>
            <h3 className="text-xl font-bold text-white mb-2">Thank you!</h3>
            <p className="text-gray-400">Thanks for your review.</p>
          </div>
        )}
      </div>
    </section>
  );
}

function FAQSection() {
  return (
    <section id="faq" className="section-padding bg-white">
      <div className="container-custom max-w-3xl">
        <h2 className="text-3xl font-bold text-center text-navy-900 mb-12">
          Your Doubts, Destroyed.
        </h2>
        
        <Accordion type="single" collapsible className="space-y-4">
          {faqs.map((faq, index) => (
            <AccordionItem
              key={index}
              value={`item-${index}`}
              className="border border-gray-200 rounded-xl overflow-hidden bg-white"
            >
              <AccordionTrigger className="px-6 py-4 text-left font-bold text-navy-900 hover:bg-gray-50 transition-colors">
                {faq.question}
              </AccordionTrigger>
              <AccordionContent className="px-6 pb-4 text-gray-600 text-sm leading-relaxed">
                <div dangerouslySetInnerHTML={{ __html: faq.answer }} />
              </AccordionContent>
            </AccordionItem>
          ))}
        </Accordion>
      </div>
    </section>
  );
}

function Guarantee() {
  return (
    <section className="section-padding bg-white">
      <div className="container-custom">
        <div className="max-w-3xl mx-auto bg-emerald-50 border-2 border-emerald-200 rounded-3xl p-8 md:p-12 text-center">
          <div className="w-20 h-20 bg-emerald-600 rounded-full flex items-center justify-center mx-auto mb-6 text-navy-900 text-3xl shadow-glow">
            <Shield size={36} />
          </div>
          <h2 className="text-2xl md:text-3xl font-bold text-navy-900 mb-4">
            My 14-Day "Do The Work" Guarantee
          </h2>
          <p className="text-gray-600 text-lg leading-relaxed">
            If you genuinely read the ebook, apply the strategies, and do not see a clear path 
            to your first ₹10,000, email me your work within 14 days. I will not only refund you 
            100%—I will personally review your work and tell you what to do next.
          </p>
        </div>
      </div>
    </section>
  );
}

function FinalCTA() {
  return (
    <section id="final-cta" className="section-padding">
      <div className="container-custom">
        <div className="bg-emerald-600 rounded-[48px] p-12 text-center relative overflow-hidden">
          <div className="relative z-10 max-w-3xl mx-auto">
            <h2 className="text-4xl md:text-6xl font-bold text-navy-900 mb-6 leading-tight">
              Do not Just Dream<br />Of Freedom.
            </h2>
            <p className="text-navy-900/70 mb-8 font-medium text-lg">
              Stop trading your life for a salary. For less than a single Swiggy order, 
              you get the exact blueprint that changed my life.
            </p>
            
            <div className="bg-white/30 backdrop-blur-md inline-block p-6 rounded-2xl border border-white/40 mb-8">
              <p className="text-red-600 font-bold text-sm">Price Jumps to ₹999 Soon!</p>
              <div className="flex items-center justify-center gap-3 mt-2">
                <span className="text-5xl font-black text-navy-900">₹499</span>
                <span className="text-xl text-navy-900/50 line-through">₹999</span>
              </div>
              <p className="text-navy-900 font-bold text-xs mt-2 uppercase tracking-wider">
                One-Time Investment
              </p>
            </div>

            <div>
              <a
                href="https://u.payu.in/nIsRdQdIBGDX"
                target="_blank"
                rel="noopener noreferrer"
                className="bg-navy-900 text-white px-8 py-4 rounded-xl inline-flex items-center gap-4 hover:bg-gray-800 transition-all shadow-lg text-xl font-bold"
              >
                Get Instant Access Now
                <ArrowRight className="group-hover:translate-x-2 transition-transform" size={20} />
              </a>
            </div>

            <p className="text-xs text-navy-900/60 mt-6 font-bold">
              14-Day Money Back Guarantee • Secure Payment via UPI/Card
            </p>
          </div>

          {/* Decorative blurs */}
          <div className="absolute -bottom-24 -left-24 w-96 h-96 bg-white/30 rounded-full blur-3xl" />
          <div className="absolute -top-24 -right-24 w-96 h-96 bg-white/30 rounded-full blur-3xl" />
        </div>
      </div>
    </section>
  );
}

function Disclaimer() {
  return (
    <section className="bg-navy-900 py-8 border-t border-gray-800">
      <div className="container-custom">
        <div className="max-w-4xl mx-auto text-center p-4 rounded-xl border border-gray-700 bg-navy-800">
          <p className="text-xs text-gray-500 leading-relaxed">
            <span className="text-red-400 font-bold uppercase tracking-wider">Disclaimer:</span>
            {' '}The income figures mentioned, including my personal results, are{' '}
            <strong>not typical</strong> and are for illustrative purposes only. Your success depends 
            entirely on your effort, time commitment, application of the strategies, and market conditions. 
            This product is educational and does not guarantee any specific income or financial results.
          </p>
        </div>
      </div>
    </section>
  );
}

function Footer() {
  const [modalOpen, setModalOpen] = useState<string | null>(null);

  const modals: Record<string, { title: string; content: React.ReactNode }> = {
    privacy: {
      title: 'Privacy Policy',
      content: (
        <div className="space-y-4 text-gray-400 text-sm">
          <p>Welcome to <strong className="text-white">zerofundedhustle</strong>. Your privacy matters to us.</p>
          <div>
            <h3 className="text-white font-semibold mb-2">1. Information We Collect</h3>
            <p>We collect details like your name and email when you purchase, basic usage data, and use cookies to improve site performance.</p>
          </div>
          <div>
            <h3 className="text-white font-semibold mb-2">2. How We Use Your Information</h3>
            <p>We use your data to process and deliver ebook purchases, communicate with you, and improve our website.</p>
          </div>
          <div>
            <h3 className="text-white font-semibold mb-2">3. Contact Us</h3>
            <p>Email: zerofundedhustle@gmail.com</p>
          </div>
        </div>
      )
    },
    terms: {
      title: 'Terms of Use',
      content: (
        <div className="space-y-4 text-gray-400 text-sm">
          <p>By accessing <strong className="text-white">zerofundedhustle.com</strong>, you agree to these Terms of Use.</p>
          <div>
            <h3 className="text-white font-semibold mb-2">1. Use of Our Website</h3>
            <p>You agree to use this website only for lawful purposes. You must not reproduce, sell, or distribute our content without permission.</p>
          </div>
          <div>
            <h3 className="text-white font-semibold mb-2">2. Products and Payments</h3>
            <p>All prices are in INR. Payments are processed securely. As our products are digital, please refer to our Refund Policy.</p>
          </div>
        </div>
      )
    },
    refund: {
      title: 'Refund Policy',
      content: (
        <div className="space-y-4 text-gray-400 text-sm">
          <p>We offer a <strong className="text-white">14-Day Action-Based Refund Guarantee</strong>.</p>
          <div>
            <h3 className="text-white font-semibold mb-2">1. Our Guarantee</h3>
            <p>If you have read the blueprint, actively applied the lessons, and still feel you did not gain value, you can request a full refund within 14 days.</p>
          </div>
          <div>
            <h3 className="text-white font-semibold mb-2">2. How to Request</h3>
            <p>Email zerofundedhustle@gmail.com with your order number and proof of work.</p>
          </div>
        </div>
      )
    },
    contact: {
      title: 'Contact Us',
      content: (
        <div className="space-y-4 text-gray-400 text-sm">
          <p>We are here to help. If you have any questions, reach out—we actually read every message.</p>
          <div>
            <h3 className="text-white font-semibold mb-2">Email</h3>
            <a href="mailto:zerofundedhustle@gmail.com" className="text-emerald-600 hover:underline">
              zerofundedhustle@gmail.com
            </a>
            <p className="mt-1">We typically reply within 24-48 hours (Mon-Fri).</p>
          </div>
        </div>
      )
    },
  };

  return (
    <footer className="bg-navy-900 text-white pt-20 pb-10 border-t border-gray-800">
      <div className="container-custom">
        <div className="grid md:grid-cols-2 lg:grid-cols-5 gap-12 mb-16">
          {/* Brand */}
          <div className="lg:col-span-2 pr-8">
            <a href="/" className="flex items-center gap-2 mb-6">
              <span className="text-2xl font-extrabold tracking-tight">
                <span className="text-white">zero</span>
                <span className="text-emerald-600">funded</span>
                <span className="text-white">hustle</span>
              </span>
            </a>
            <p className="text-gray-400 text-sm mb-8 leading-relaxed">
              Built in India, for the Indian Hustler. We provide the <strong>blueprints</strong>{' '}
              you need to <strong>escape the rat race</strong> without investors or debt.
            </p>
            <div className="flex space-x-4 mt-6">
              <a href="https://twitter.com/zerofundedhustl" target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-emerald-600 transition-colors">
                <span className="sr-only">Twitter</span>
                <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M8.29 20.251c7.547 0 11.675-6.253 11.675-11.675 0-.178 0-.355-.012-.53A8.348 8.348 0 0022 5.92a8.19 8.19 0 01-2.357.646 4.118 4.118 0 001.804-2.27 8.224 8.224 0 01-2.605.996 4.107 4.107 0 00-6.993 3.743 11.65 11.65 0 01-8.457-4.287 4.106 4.106 0 001.27 5.477A4.072 4.072 0 012.8 9.713v.052a4.105 4.105 0 003.292 4.022 4.095 4.095 0 01-1.853.07 4.108 4.108 0 003.834 2.85A8.233 8.233 0 012 18.407a11.616 11.616 0 006.29 1.84" /></svg>
              </a>
              <a href="https://www.instagram.com/zerofundedhustle/" target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-emerald-600 transition-colors">
                <span className="sr-only">Instagram</span>
                <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path fillRule="evenodd" d="M12.315 2c2.43 0 2.784.013 3.808.06 1.064.049 1.791.218 2.427.465a4.902 4.902 0 011.772 1.153 4.902 4.902 0 011.153 1.772c.247.636.416 1.363.465 2.427.048 1.067.06 1.407.06 4.123v.08c0 2.643-.012 2.987-.06 4.043-.049 1.064-.218 1.791-.465 2.427a4.902 4.902 0 01-1.153 1.772 4.902 4.902 0 01-1.772 1.153c-.636.247-1.363.416-2.427.465-1.067.048-1.407.06-4.123.06h-.08c-2.643 0-2.987-.012-4.043-.06-1.064-.049-1.791-.218-2.427-.465a4.902 4.902 0 01-1.772-1.153 4.902 4.902 0 01-1.153-1.772c-.247-.636-.416-1.363-.465-2.427-.047-1.024-.06-1.379-.06-3.808v-.63c0-2.43.013-2.784.06-3.808.049-1.064.218-1.791.465-2.427a4.902 4.902 0 011.153-1.772A4.902 4.902 0 015.45 2.525c.636-.247 1.363-.416 2.427-.465C8.901 2.013 9.256 2 11.685 2h.63zm-.081 1.802h-.468c-2.456 0-2.784.011-3.807.058-.975.045-1.504.207-1.857.344-.467.182-.8.398-1.15.748-.35.35-.566.683-.748 1.15-.137.353-.3.882-.344 1.857-.047 1.023-.058 1.351-.058 3.807v.468c0 2.456.011 2.784.058 3.807.045.975.207 1.504.344 1.857.182.466.399.8.748 1.15.35.35.683.566 1.15.748.353.137.882.3 1.857.344 1.054.048 1.37.058 4.041.058h.08c2.597 0 2.917-.01 3.96-.058.976-.045 1.505-.207 1.858-.344.466-.182.8-.398 1.15-.748.35-.35.566-.683.748-1.15.137-.353.3-.882.344-1.857.048-1.055.058-1.37.058-4.041v-.08c0-2.597-.01-2.917-.058-3.96-.045-.976-.207-1.505-.344-1.858a3.097 3.097 0 00-.748-1.15 3.098 3.098 0 00-1.15-.748c-.353-.137-.882-.3-1.857-.344-1.023-.047-1.351-.058-3.807-.058zM12 6.865a5.135 5.135 0 110 10.27 5.135 5.135 0 010-10.27zm0 1.802a3.333 3.333 0 100 6.666 3.333 3.333 0 000-6.666zm5.338-3.205a1.2 1.2 0 110 2.4 1.2 1.2 0 010-2.4z" clipRule="evenodd" /></svg>
              </a>
            </div>
          </div>

          {/* Links */}
          <div>
            <h4 className="font-bold mb-6 text-sm uppercase tracking-wider text-gray-300">Product</h4>
            <ul className="space-y-4 text-sm text-gray-400">
              <li><a href="#blueprints" className="hover:text-emerald-600 transition-colors">The Blueprint</a></li>
              <li><a href="#proof" className="hover:text-emerald-600 transition-colors">Proof</a></li>
              <li><a href="#bonuses" className="hover:text-emerald-600 transition-colors">Bonuses</a></li>
              <li><a href="#reviews" className="hover:text-emerald-600 transition-colors">Reviews</a></li>
            </ul>
          </div>

          <div>
            <h4 className="font-bold mb-6 text-sm uppercase tracking-wider text-gray-300">Legal</h4>
            <ul className="space-y-4 text-sm text-gray-400">
              <li><button onClick={() => setModalOpen('privacy')} className="hover:text-emerald-600 transition-colors text-left">Privacy Policy</button></li>
              <li><button onClick={() => setModalOpen('terms')} className="hover:text-emerald-600 transition-colors text-left">Terms of Use</button></li>
              <li><button onClick={() => setModalOpen('refund')} className="hover:text-emerald-600 transition-colors text-left">Refund Policy</button></li>
            </ul>
          </div>

          <div>
            <h4 className="font-bold mb-6 text-sm uppercase tracking-wider text-gray-300">Connect</h4>
            <ul className="space-y-4 text-sm text-gray-400">
              <li><button onClick={() => setModalOpen('contact')} className="hover:text-emerald-600 transition-colors text-left">Contact Us</button></li>
            </ul>
          </div>
        </div>

        <div className="border-t border-gray-800 pt-8 flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-gray-500 text-xs">
            Copyright © 2025 <strong>zerofundedhustle</strong>. All Rights Reserved.
          </p>
        </div>
      </div>

      {/* Modals */}
      <Dialog open={!!modalOpen} onOpenChange={() => setModalOpen(null)}>
        <DialogContent className="bg-navy-900 border-gray-700 text-white max-w-2xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{modalOpen ? modals[modalOpen].title : ''}</DialogTitle>
          </DialogHeader>
          {modalOpen && modals[modalOpen].content}
        </DialogContent>
      </Dialog>
    </footer>
  );
}

function StickyBanner() {
  const [isVisible, setIsVisible] = useState(false);
  const heroRef = useRef<HTMLElement | null>(null);
  const finalCtaRef = useRef<HTMLElement | null>(null);

  useEffect(() => {
    heroRef.current = document.getElementById('hero-section');
    finalCtaRef.current = document.getElementById('final-cta');

    const handleScroll = () => {
      if (!heroRef.current || !finalCtaRef.current) return;
      
      const heroRect = heroRef.current.getBoundingClientRect();
      const finalCtaRect = finalCtaRef.current.getBoundingClientRect();
      
      const shouldShow = heroRect.bottom < 0;
      const shouldHide = finalCtaRect.top < window.innerHeight - 200;
      
      setIsVisible(shouldShow && !shouldHide);
    };

    window.addEventListener('scroll', handleScroll);
    handleScroll();
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <div 
      className={`fixed bottom-0 left-0 w-full z-50 transform transition-transform duration-300 ${
        isVisible ? 'translate-y-0' : 'translate-y-full'
      }`}
    >
      <div className="bg-navy-900 rounded-t-[2.5rem] shadow-[0_-10px_40px_-15px_rgba(0,0,0,0.3)] border-t border-gray-700 px-6 py-3 w-full">
        <div className="container-custom max-w-4xl flex items-center justify-between gap-4">
          <div className="flex flex-col sm:flex-row sm:items-center gap-1 sm:gap-4">
            <div className="flex items-baseline gap-2">
              <span className="text-xl md:text-2xl font-black text-white">₹499</span>
              <span className="text-xs md:text-sm text-gray-400 line-through">₹999</span>
            </div>
            <div className="flex flex-col sm:flex-row sm:items-center gap-0.5 sm:gap-4">
              <span className="text-[10px] sm:text-xs text-red-400 font-bold uppercase tracking-wider animate-pulse">
                Price jumps to ₹999 soon!
              </span>
              <span className="hidden sm:block text-gray-600">|</span>
              <span className="text-sm md:text-base text-emerald-600 font-bold">
                Less than a large pizza 🍕
              </span>
            </div>
          </div>
          <a
            href="https://u.payu.in/nIsRdQdIBGDX"
            target="_blank"
            rel="noopener noreferrer"
            className="btn-primary text-sm min-w-[160px]"
          >
            Get Instant Access
            <ArrowRight size={16} />
          </a>
        </div>
      </div>
    </div>
  );
}

// Main App Component
function App() {
  return (
    <div className="min-h-screen bg-navy-900">
      <Navbar />
      
      <main>
        <div id="hero-section">
          <Hero />
        </div>
        <TrustBanner />
        <ScrollingTicker />
        <LeadMagnet />
        <PainPoints />
        <AudienceFilter />
        <Personas />
        <Mentor />
        <TransitionBanner />
        <IncomeProof />
        <Pillars />
        <Blueprints />
        <ProductBenefits />
        <Mistakes />
        <ComparisonTable />
        <Bonuses />
        <Timeline />
        <Testimonials />
        <ReviewForm />
        <FAQSection />
        <Guarantee />
        <FinalCTA />
        <Disclaimer />
      </main>
      
      <Footer />
      <StickyBanner />
    </div>
  );
}

export default App;
